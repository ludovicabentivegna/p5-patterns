size= 35
widthMult=5
heightMult=2

let x=0
let y=0

 function setup(){
createCanvas(windowWidth, windowHeight)
   angleMode(DEGREES)
strokeWeight(3)
   
   StartR= random(165); //imposto dati colore di partenza
   StartG= random(165);
   StartB= random (165);
   background(StartR+45, StartG+45, StartB+45) // scelta randomica dei colori dello sfondo
}
   
function draw(){
   fill(random(StartR, StartR+90), random(StartG, StartG+90), random(StartB, StartB+90)); //scelta randomica del colore dei rettangoli
 
  push()
translate(x+size/2, y+size/2)
  rotate(floor(random(8))*90)
   rect(0,0,size*floor(random(1, widthMult)), size*floor(random(1, heightMult))) //floor calcola il valore intero più vicino
pop()


x=x+size
  if (x > width) { 
    x = 0  ;
  y=y+size*2}
}