function setup() {
 
  createCanvas(windowWidth, windowHeight);
  background(255);
  noFill();
  strokeCap(SQUARE);
  numb = 12;
  size = width / numb;
  strokeWeight(max(1, size / 4));
  stroke(0);
  for (i = 0; i < numb + 1; i++) { //loop
    for (j = 0; j < numb + 1; j++) {
      stroke(44,73,127);
      push();
      translate(i * size, j * size);
      rotate(floor(random(4)) * PI * 0.5);
      type = random(2); 
      if (type < 1.8) {
        arc(size / 2, -size / 2, size, size, PI * 0.5, PI);
        arc(-size / 2, size / 2, size, size, -PI * 0.5, 0);
      } else if (type < 2) {
        line(-size / 2, 0, size / 2, 0);
        line(0, -size / 2, 0, size / 2);
      } 
      pop();
    }
  }
}